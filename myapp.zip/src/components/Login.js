import React, { useState } from 'react'
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom'

export default function Login() {
    const navigate = useNavigate()
    const [email, setEmail] = useState('')
    const [signedupEmail, setsignedupEmail] = useState('')
    const [password, setpassword] = useState('')
    const [signedupPassword, setsignedupPassword] = useState('')
    const [disabledBtn, setdisabledBtn] = useState(true)
    const [isInavalid, setisInavalid] = useState(false)
    const [signedupDisabledBtn, setsignedupDisabledBtn] = useState(true)
    const [dob, setDob] = useState("");
    const [image, setImage] = useState("");
    const [hobby, setHobby] = useState("");
    const [gender, setGender] = useState("");
    const [name, setName] = useState("");

    React.useEffect(() => {
        if (email !== '' && password !== '') {
            setdisabledBtn(false)
        }
    }, [email, password]);

    React.useEffect(() => {
        if (signedupEmail !== '' &&
            signedupPassword !== '' &&
            dob !== "" &&
            image !== "" &&
            hobby !== "" &&
            gender !== "" &&
            name !== ""
        ) {
            setsignedupDisabledBtn(false)
        }
    }, [signedupEmail, signedupPassword,
        dob,
        image,
        hobby,
        gender,
        name]);

    const signUp = () => {
        localStorage.setItem('username', name)
        localStorage.setItem('email', signedupEmail)
        localStorage.setItem('dob', dob)
        localStorage.setItem('hobby', hobby)
        localStorage.setItem('image', image)
        localStorage.setItem('gender', gender)
        localStorage.setItem('password', signedupPassword)
    }
    const login = () => {
        console.log(email)
        console.log(password)
        let databaseEmail = localStorage.getItem('email')
        let databasePassword = localStorage.getItem('password')
        if (email === databaseEmail && password === databasePassword) {
            localStorage.setItem('isLoggedIn', 'true')
            navigate('/home')
            window.location.reload();
        } else{
            setisInavalid(true)
        }
    }

    return (
        <div>
            <h1>Sign up</h1>
            <div className="container">
                <label htmlFor="name"><b>Name</b></label>
                <input type="text" placeholder="Enter Name" name="name" required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <label htmlFor="email">Email </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter Email"
                    value={signedupEmail}
                    onChange={(e) => setsignedupEmail(e.target.value)}
                />
                <label htmlFor="dob">Dob: </label>
                <input
                    type="date"
                    id="dob"
                    name="dob"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                />
                <label htmlFor="image">Image: </label>
                <input
                    type="file"
                    id="image"
                    name="image"
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                />
                <label htmlFor="hobby">hobby: </label>
                <input
                    type="text"
                    id="hobby"
                    name="hobby"
                    value={hobby}
                    onChange={(e) => setHobby(e.target.value)}
                />
                <label htmlFor="male">Male</label>
                <input type="radio" id="male" name="male" value="male" checked={gender === 'male'} onChange={(e) => setGender(e.target.value)} />

                <label htmlFor="female">Female</label>
                <input type="radio" id="female" name="female" value="female" checked={gender === 'female'} onChange={(e) => setGender(e.target.value)} />
                <br></br>
                <label htmlFor="signuppsw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="signuppsw" required onChange={(e) => setsignedupPassword(e.target.value)} />
                <Button onClick={signUp} variant="contained" disabled={signedupDisabledBtn}>Signup</Button>
            </div>
            <h1>Login</h1>
            <div className="container">
                <label htmlFor="uname"><b>Email</b></label>
                <input
                    type="email"
                    placeholder="Enter Email" name="uname" required onChange={(e) => setEmail(e.target.value)} />
                <label htmlFor="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="psw" required onChange={(e) => setpassword(e.target.value)} />
                {isInavalid && <span style={{ color: 'red' }}>Invalid email or password</span>}
                <br></br>
                <Button onClick={login} variant="contained" disabled={disabledBtn}>Login</Button>
            </div>
        </div >
    )
}
