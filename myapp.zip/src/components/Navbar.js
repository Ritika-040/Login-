import * as React from 'react';
import { useLocation, useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import FlagIcon from '@mui/icons-material/Flag';
import SportsIcon from '@mui/icons-material/Sports';
import ConnectedTvIcon from '@mui/icons-material/ConnectedTv';
import PublicIcon from '@mui/icons-material/Public';
import HubIcon from '@mui/icons-material/Hub';
import BusinessIcon from '@mui/icons-material/Business';
import PollIcon from '@mui/icons-material/Poll';

export default function Navbar() {
  const [value, setValue] = React.useState(0);
  let navigate = useNavigate();
  const { pathname } = useLocation();

  React.useEffect(() => {
    if (pathname === '/home') {
      setValue(0)
    } else if (pathname === "/india") {
      setValue(1)
    } else if (pathname === "/sports") {
      setValue(2)
    } else if (pathname === "/technology") {
      setValue(3)
    } else if (pathname === "/business") {
      setValue(4)
    } else if (pathname === "/politics") {
      setValue(5)
    } else if (pathname === "/ndtv") {
      setValue(6)
    }

  }, [pathname]);

  const handleChange = (newValue) => {
    if (newValue === 0) {
      navigate("/home")
    } else if (newValue === 1) {
      navigate("/india")
    } else if (newValue === 2) {
      navigate("/sports")
    } else if (newValue === 3) {
      navigate("/technology")
    } else if (newValue === 4) {
      navigate("/business")
    } else if (newValue === 5) {
      navigate("/politics")
    } else if (newValue === 6) {
      navigate("/ndtv")
    }
    setValue(newValue)
  }
  return (
    <Box>
      <BottomNavigation
        showLabels
        value={value}
        onChange={(event, newValue) => {
          handleChange(newValue);
        }}
      >
        <BottomNavigationAction label="World" icon={<PublicIcon />} />
        <BottomNavigationAction label="India" icon={<FlagIcon />} />
        <BottomNavigationAction label="Sports" icon={<SportsIcon />} />
        <BottomNavigationAction label="Technology" icon={<HubIcon />} />
        <BottomNavigationAction label="Business" icon={<BusinessIcon />} />
        <BottomNavigationAction label="Politics" icon={<PollIcon />} />
        <BottomNavigationAction label="NDTV" icon={<ConnectedTvIcon />} />
      </BottomNavigation>
    </Box>
  );
}