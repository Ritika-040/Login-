import * as React from 'react';
import axios from "axios";
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';


export default function Technology() {
    const [newsData, setNewsData] = React.useState([]);
    React.useEffect(() => {
        axios.get('https://newsapi.org/v2/top-headlines?category=technology&apiKey=70d82be6eeec451d8d128d8ea02b3f8b').then((response) => {
            if (response && response.data && response.data.articles)
                setNewsData(response.data.articles);
        });
    }, []);
    return (
        <>
            {newsData && newsData.length !== 0 && newsData.map((item, index) => {
                return <Card key={index} style={{ width: '70%', margin: 'auto', marginTop: '10px' }}>
                    <CardMedia
                        component="img"
                        height="194"
                        image={item.urlToImage}
                        alt="image"
                        style={{ objectFit: 'unset' }}
                    />
                    <CardContent>
                        <Typography variant="body2" color="text.secondary">
                            {item.content && item.content + ' '}
                            <a href={item.url} target="_blank">Click here</a>
                        </Typography>
                    </CardContent>
                </Card>

            })}
        </>
    );
}
