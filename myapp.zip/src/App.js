import './App.css';
import { Routes, Route, Router, Navigate } from "react-router-dom"
import Home from './components/Home';
import Navbar from './components/Navbar';
import India from './components/India';
import Sports from './components/Sports';
import Technology from './components/Technology';
import Business from './components/Business';
import Politics from './components/Politics';
import Login from './components/Login';
import NDTV from './components/Ndtv';
import ProtectedRoutes from './components/ProtectedRoutes';
import PublicRoutes from './components/PublicRoutes';
import React, { useState } from 'react';

function App() {
  const [isLoggedIn, setisLoggedIn] = useState(false)
  const isLogin = localStorage.getItem('isLoggedIn')
  React.useEffect(() => {
    setisLoggedIn(isLogin)
  }, [isLogin]);
  return (
    <div>
      {
        isLoggedIn &&
        <Navbar />
      }
      <Routes>
        <Route path="/" element={<ProtectedRoutes />}>
          <Route path="/" element={<Navigate replace to="home" />} />
          <Route path="/home" element={<Home />} />
          <Route path="/india" element={<India />} />
          <Route path="/sports" element={<Sports />} />
          <Route path="/technology" element={<Technology />} />
          <Route path="/business" element={<Business />} />
          <Route path="/politics" element={<Politics />} />
          <Route path="/Ndtv" element={<NDTV />} />
        </Route>
        <Route path="login" element={<PublicRoutes />}>
          <Route path="/login" element={<Login />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
